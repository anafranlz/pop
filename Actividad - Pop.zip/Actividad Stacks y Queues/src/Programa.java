
public class Programa {

	public static void main(String[] args) {
		
		MyStack dulce = new MyStack(5);
		dulce.push('c');
		dulce.push('a');
		dulce.push('n');
		dulce.push('d');
		dulce.push('y');
		
		for(int i = 0; i<dulce.stack.length; i++)
		{
			System.out.print(dulce.stack[i]);
		}
		//dulce.push('s');
		
		System.out.println();
		
		for(int i = 0; i<dulce.stack.length; i++)
		{
			System.out.print(dulce.pop());
		}
		
	}
}
