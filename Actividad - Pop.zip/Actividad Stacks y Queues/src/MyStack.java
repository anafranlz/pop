
public class MyStack {

	int i;
	int max;
	int top;
	char valor;
	public char[] stack;
	
	public MyStack(int tamanoStack)
	{
		this.stack = new char[tamanoStack];
		this.max = this.stack.length;
		this.top = 0;
	}
	
	public char pop()
	{
		if(top == 0)
		{
			System.out.println("Stack is empty");
			return 0;
		}
		else
		{
			valor = stack[top - 1];
			stack[top - 1] = 0;
			top--;
			return valor;
		}
	}
	
	public void push(char valor)
	{
		if(top == max)
		{
		System.out.println("Stack is full");
		return;
		}
		else 
		{
			stack[top] = valor;
			top++; 
		}
	}
}
